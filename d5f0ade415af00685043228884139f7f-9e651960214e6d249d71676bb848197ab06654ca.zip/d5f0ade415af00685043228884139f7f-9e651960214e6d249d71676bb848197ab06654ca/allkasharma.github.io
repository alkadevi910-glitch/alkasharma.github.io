<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vishuddha Oil</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #fffdf5;
}

header {
    background-color: #f7e8a4;
    padding: 20px;
    text-align: center;
}

header h1 {
    margin: 0;
    color: #6b4f00;
}

.hero {
    text-align: center;
    padding: 40px;
}

.hero img {
    width: 300px;
    border-radius: 15px;
}

.section {
    padding: 30px;
    text-align: center;
}

.benefits {
    display: flex;
    overflow-x: auto;
    gap: 20px;
    padding: 20px;
}

.benefit-card {
    min-width: 250px;
    background: #fff7d6;
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.products {
    display: flex;
    justify-content: center;
    gap: 40px;
    flex-wrap: wrap;
}

.product {
    background: #fff7d6;
    padding: 20px;
    border-radius: 15px;
    width: 200px;
}

button {
    background-color: #f2c200;
    border: none;
    padding: 10px 15px;
    border-radius: 10px;
    cursor: pointer;
    margin-top: 10px;
}

button:hover {
    background-color: #d9a800;
}

footer {
    text-align: center;
    padding: 20px;
    background-color: #f7e8a4;
}
</style>

<script>
function order(product) {
    let phone = "9163231673";
    let message = "Hello, I want to order Vishuddha Oil - " + product;
    let url = "https://wa.me/91" + phone + "?text=" + encodeURIComponent(message);
    window.open(url, "_blank");
}
</script>

</head>

<body>

<header>
    <h1>Vishuddha Oil</h1>
    <p>Pure Cold Press Mustard Oil</p>
</header>

<div class="hero">
    <img src="https://images.unsplash.com/photo-1604908176997-4310b8f1d48f" alt="Mustard Oil">
    <h2>100% Pure • Natural • Healthy</h2>
</div>

<div class="section">
    <h2>Benefits of Cold Press Oil</h2>
    <div class="benefits">
        <div class="benefit-card">🌿 Rich in nutrients & antioxidants</div>
        <div class="benefit-card">💛 Good for heart health</div>
        <div class="benefit-card">🔥 Improves digestion</div>
        <div class="benefit-card">🌱 No chemicals or heat processing</div>
    </div>
</div>

<div class="section">
    <h2>Buy Now</h2>
    <div class="products">

        <div class="product">
            <h3>1 Litre Bottle</h3>
            <p>Fresh & Pure</p>
            <button onclick="order('1 Litre Bottle')">Order Now</button>
        </div>

        <div class="product">
            <h3>5 Litre Bottle</h3>
            <p>Family Pack</p>
            <button onclick="order('5 Litre Bottle')">Order Now</button>
        </div>

    </div>
</div>

<footer>
    <p>Contact: 9163231673</p>
    <p>© 2026 Vishuddha Oil</p>
</footer>

</body>
</html>